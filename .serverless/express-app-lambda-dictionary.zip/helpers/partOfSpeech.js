exports.PART_OF_SPEECH_DICT = {
  adjectives: 'a.',
  adverbs: 'adv.',
  interjections: 'interj.',
  nouns: 'n.',
  verbs: 'v.',
  pronouns: 'pron.',
  prepositions: 'prep.',
  conjunctions: 'conj.',
};
