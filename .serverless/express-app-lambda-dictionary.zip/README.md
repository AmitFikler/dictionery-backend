# Dictionary

## Screenshots

![Alt text](https://i.ibb.co/yXQnMj1/Screenshot-2022-01-23-030931.png)
![Alt text](https://i.ibb.co/PYDbqBY/Screenshot-2022-01-23-031241.png)
![Alt text](https://i.ibb.co/K900fmN/Screenshot-2022-01-23-031310.png)
